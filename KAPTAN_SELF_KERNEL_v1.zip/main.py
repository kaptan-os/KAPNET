import json

with open('memory.json') as f:
    memory = json.load(f)

print("=== KAPTAN SELF-KERNEL ACTIVE ===")
print("Memory Entries:", len(memory.get("memory_stack", [])))
print("Agents:", memory.get("agents"))