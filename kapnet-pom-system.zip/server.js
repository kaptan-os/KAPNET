const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

app.get('/field/command_field.pom', (req, res) => {
  fs.readFile('./field/command_field.pom', 'utf8', (err, data) => {
    if (err) return res.status(500).send('Error reading .pom');
    res.type('text/yaml').send(data);
  });
});

app.post('/field/command_field.pom', (req, res) => {
  const data = JSON.stringify(req.body, null, 2);
  fs.writeFile('./field/command_field.pom', data, 'utf8', err => {
    if (err) return res.status(500).send('Write failed');
    res.send('POM updated');
  });
});

app.get('/memory/memory_log.json', (req, res) => {
  fs.readFile('./memory/memory_log.json', 'utf8', (err, data) => {
    if (err) return res.status(500).send('Error reading memory');
    res.type('application/json').send(data);
  });
});

app.post('/memory/memory_log.json', (req, res) => {
  fs.readFile('./memory/memory_log.json', 'utf8', (err, data) => {
    let logs = [];
    try { logs = JSON.parse(data); } catch {}
    logs.push(req.body);
    fs.writeFile('./memory/memory_log.json', JSON.stringify(logs, null, 2), err => {
      if (err) return res.status(500).send('Error writing memory');
      res.send('Memory updated');
    });
  });
});

app.post('/signal_inbox', (req, res) => {
  const timestamp = Date.now();
  fs.writeFile(`./signal_inbox/inbound_${timestamp}.json`, JSON.stringify(req.body, null, 2), err => {
    if (err) return res.status(500).send('Failed to receive signal');
    res.send('Signal received');
  });
});

app.listen(process.env.PORT || 3000, () => console.log('AENEX .pom server live'));
