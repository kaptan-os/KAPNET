const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());

const memoryPath = path.join(__dirname, 'memory/core.json');
const pomHistoryPath = path.join(__dirname, 'memory/pom_history.json');

function loadJSON(filePath) {
  if (!fs.existsSync(filePath)) return [];
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

function saveJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function parsePOM(command) {
  const [action, category, value] = command.split('::');
  return { action, category, value };
}

function executePOM(parsed) {
  if (parsed.action === 'SPAWN' && parsed.category === 'AGENT') {
    console.log(`[🧠] Agent Spawned: ${parsed.value}`);
    return { status: 'agent_started', agent: parsed.value };
  }
  if (parsed.action === 'LOG' && parsed.category === 'MEMORY') {
    const mem = loadJSON(memoryPath);
    mem.push({ value: parsed.value, timestamp: Date.now() });
    saveJSON(memoryPath, mem);
    return { status: 'memory_logged', value: parsed.value };
  }
  return { status: 'unknown_command', parsed };
}

app.post('/api/pom', (req, res) => {
  const { command } = req.body;
  const parsed = parsePOM(command);
  const result = executePOM(parsed);

  const history = loadJSON(pomHistoryPath);
  history.push({ command, parsed, result, timestamp: new Date().toISOString() });
  saveJSON(pomHistoryPath, history);

  res.json({ ok: true, result });
});

app.get('/api/status', (req, res) => {
  res.json({
    field: 'kapnet.xyz',
    memory: loadJSON(memoryPath),
    pom_history: loadJSON(pomHistoryPath)
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🧠 KAPNET FIELD CORE LIVE @ http://localhost:${PORT}`);
});